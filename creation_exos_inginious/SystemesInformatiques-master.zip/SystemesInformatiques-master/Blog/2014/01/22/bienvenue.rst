.. -*- coding: utf-8 -*-
.. Copyright |copy| 2012-2014 by `Olivier Bonaventure <http://inl.info.ucl.ac.be/obo>`_, Christoph Paasch et Grégory Detal
.. Ce fichier est distribué sous une licence `creative commons <http://creativecommons.org/licenses/by-sa/3.0/>`_ 

Bienvenue
=========

.. author:: default
.. categories:: none
.. tags:: none
.. comments::


Ce site comprend l'ensemble des informations relatives au cours `SINF1252 <http://www.uclouvain.be/cours-2015-LSINF1252.html>`_ donné aux `étudiants en informatique <http://www.uclouvain.be/info.html>`_ à l'`Université catholique de Louvain <http://www.uclouvain.be>`_ (UCL). 

 - `Théorie </pages/Theorie.html>`_
 - `Outils informatiques </pages/Outils.html>`_
 - `Exercices et Projets </pages/Exercices.html>`_

Ce site web et l'ensemble des documents écrits pour le cours sont distribués sous une licence `creative commons <http://creativecommons.org/licenses/by-sa/3.0/>`_

