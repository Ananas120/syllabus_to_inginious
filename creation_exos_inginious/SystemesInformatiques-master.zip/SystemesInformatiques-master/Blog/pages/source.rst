.. -*- coding: utf-8 -*-
.. Copyright |copy| 2012-2014 by `Olivier Bonaventure <http://inl.info.ucl.ac.be/obo>`_, Christoph Paasch et Grégory Detal
.. Ce fichier est distribué sous une licence `creative commons <http://creativecommons.org/licenses/by-sa/3.0/>`_ 

Source
======


L'ensemble des sources de ce site web et des notes du cours de systèmes informatiques sont disponibles depuis  https://github.com/obonaventure/SystemesInformatiques 

Le site web a été écrit en restructured text en utilisant l'outil tinkerer.

Les notes sont écrites en restructured text et converties en HTML, pdf et epub en utilisant `sphinx <http://sphinx.pocoo.org>`_

Toutes les suggestions pour l'amélioration des notes, exercices ou de la section relative aux outils sont les bienvenues.
