.. -*- coding: utf-8 -*-
.. Copyright |copy| 2012-2014 by `Olivier Bonaventure <http://inl.info.ucl.ac.be/obo>`_, Christoph Paasch et Grégory Detal
.. Ce fichier est distribué sous une licence `creative commons <http://creativecommons.org/licenses/by-sa/3.0/>`_  

Auteurs
=======

Les documents relatifs au cours ont été écrits par différents auteurs.

La partie théorique a été principalement écrite par Olivier Bonaventure avec l'aide de Grégory Detal, Christoph Paasch et de nombreuses suggestions d'étudiants et d'assistants.

La partie relative aux outils informatiques a été initié par Olivier Bonaventure, Grégory Detal et Christoph Paasch, mais la majorité du texte a été écrit par des étudiants après avoir suivi le cours avec fruit. Benoît Legat a écrit toute la section sur git. Nicolas Houtain et Maxime Demol ont écrit notamment les sections relatives au shell. Antoine Cailliau a écrit la section sur Cunit.

Les exercices ont été écrits par Olivier Bonaventure, Grégory Detal et Christoph Paasch. Floriant Chalet et Kilian Verhetsel ont fortement contribué aux exercices avec correction automatique sur la plateforme pythia/inginious.




