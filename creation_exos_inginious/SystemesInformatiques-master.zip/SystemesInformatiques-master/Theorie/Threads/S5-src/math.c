/**************************************
 * min.c
 *
 * Programme d'exemple pour le linker
 *
 **************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[])  {
  printf("Le cosinus de PI vaut : %f\n",cos(M_PI));
  return(EXIT_SUCCESS);

}
