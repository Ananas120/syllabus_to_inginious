/**************************************
 * imax.h
 *
 * Programme d'exemple d'utilisation de
 * librairie
 *
 *************************************/
///AAA

int imax(int,int);

///BBB
