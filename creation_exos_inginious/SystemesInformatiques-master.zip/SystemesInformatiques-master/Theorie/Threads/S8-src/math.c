/**************************************
 * math.c
 *
 * Programme d'exemple d'utilisation de
 * la librairie math
 *
 *************************************/
///AAA
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main (int argc, char *argv[])  {
  double n1=1.0;
  double n2=-3.14;
  printf("Maximum : %f\n",fmax(n1,n2));

  return(EXIT_SUCCESS);
}
///BBB
