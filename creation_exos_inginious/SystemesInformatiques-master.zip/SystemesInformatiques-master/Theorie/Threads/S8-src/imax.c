/**************************************
 * imax.c
 *
 * Programme d'exemple d'utilisation de
 * librairie
 *
 *************************************/
///AAA

int imax(int i, int j) {
  return ((i>j) ? i : j);

}
///BBB
