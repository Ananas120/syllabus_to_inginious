/**************************************
 * math.c
 *
 * Programme d'exemple d'utilisation de
 * la librairie math
 *
 *************************************/
///AAA
#include <stdio.h>
#include <stdlib.h>
#include "imax.h"

int main (int argc, char *argv[])  {
  int n1=1;
  int n2=-3;
  printf("Maximum : %d\n",imax(n1,n2));

  return(EXIT_SUCCESS);
}
///BBB
