/**************************************
 * failure.c
 *
 * Programme minimal qui échoue toujours
 *
 **************************************/
#include <stdlib.h>
int main( int argc, char *argv[] ) {
  return(EXIT_FAILURE);
}
