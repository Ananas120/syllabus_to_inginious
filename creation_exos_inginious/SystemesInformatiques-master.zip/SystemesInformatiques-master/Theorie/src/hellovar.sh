#!/bin/bash
PROG="SINF"
COURS=1252
echo $PROG$COURS
