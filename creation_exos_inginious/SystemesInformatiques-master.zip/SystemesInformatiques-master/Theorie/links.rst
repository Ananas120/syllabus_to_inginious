.. Links to be included



.. _intel : http://www.intel.com
.. _python : http://www.python.org
.. _perl : http://www.perl.org
.. _Git : http://git-scm.com/
.. _subversion : http://subversion.apache.org/
.. _ISO-8859 : http://en.wikipedia.org/wiki/ISO/IEC_8859
.. _Unicode: http://en.wikipedia.org/wiki/Unicode
.. _Endianness: http://en.wikipedia.org/wiki/Endianness
.. _llvm: http://llvm.org





