/**************************************
 * var.c
 *
 * Programme d'exemple pour localiser
 * les variables en mémoire
 *
 **************************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
   // affiche sur la sortie standard
   printf("Hello, world!\n");

   return(EXIT_SUCCESS);
}
