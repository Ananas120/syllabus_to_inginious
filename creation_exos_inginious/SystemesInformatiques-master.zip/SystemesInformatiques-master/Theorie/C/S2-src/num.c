/***********************************************
 * num
 *
 * Déclaration de nombres
 *
 ***********************************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  ///AAA

  int i;
  i = 123;   // décimal
  i = 0x7b;  // hexadécimal
  i = 0173;  // octal !!
  //  i = 0b1111011; // binaire, seulement certains compilateurs

  ///BBB
  
  return EXIT_SUCCESS;
}
