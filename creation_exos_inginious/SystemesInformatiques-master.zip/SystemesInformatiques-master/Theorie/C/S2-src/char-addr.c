/***********************************************
 * charaddr.c
 *
 * Pointeurs et chaînes de caractères
 *
 ***********************************************/

#include <stdio.h>
#include <stdlib.h>





///BBB
int main(int argc, char *argv[]) {

///AAA

  int i;
  char name1[] = "str";
  //  char name2[] = "SINF1252";

  for(i=0;i<10;i++) {
    printf("%c",name1[i]);
  }

  return(EXIT_SUCCESS);
}

