/***********************************************
 * fct.h
 *
 * Exemple de signatures de fonctions
 *
 ***********************************************/

///HHH
int times_two(int *);
int timestwo(int *);
///III
