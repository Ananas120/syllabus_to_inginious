/**************************************
 * min.c
 *
 * Programme d'exemple pour le linker
 *
 **************************************/

#include "min.h"

float min(float a, float b) {
  if(a<b)
    return a;
  else
    return b;
}


