/**************************************
 * static.c
 *
 * Programme d'exemple de variables static
éé
 *
 **************************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
   // affiche sur la sortie standard
   printf("Hello, world!\n");

   return(EXIT_SUCCESS);
}
