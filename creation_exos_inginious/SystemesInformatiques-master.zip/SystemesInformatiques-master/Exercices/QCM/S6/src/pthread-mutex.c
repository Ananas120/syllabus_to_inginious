/**************************************
 * pthread-mutex.c
 *
 * Programme d'exemple de pthread avec
 * utilisation de mutex pour éviter une
 * violation de section critique
 *
 **************************************/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>


void error(int err, char *msg) {
  fprintf(stderr,"%s a retourné %d, message d'erreur : %s\n",msg,err,strerror(errno));
  exit(EXIT_FAILURE);
}

///AAA
#include <pthread.h>
#define NTHREADS 4

long a=5;
long b=7;
long c=9;

pthread_mutex_t x;
pthread_mutex_t y;
pthread_mutex_t z;


void update(int * val, pthread_mutex_t * mutex) {

  err=pthread_mutex_lock(mutex);
  if(err!=0)
    error(err,"pthread_mutex_lock");
  *val=(*val)+1;
  err=pthread_mutex_unlock(mutex);
  if(err!=0)
    error(err,"pthread_mutex_unlock");
  return NULL;
}

void  update2(int * val1, int * val2, pthread_mutex_t * mutex1, pthread_mutex_t * mutex2) {

  err=pthread_mutex_lock(mutex1);
  if(err!=0)
    error(err,"pthread_mutex_lock");
  err=pthread_mutex_lock(mutex2);
  if(err!=0)
    error(err,"pthread_mutex_lock");

  *val1=(*val2)+1;
  *val2=(*val1)+1;

  err=pthread_mutex_unlock(mutex1);
  if(err!=0)
    error(err,"pthread_mutex_unlock");

  err=pthread_mutex_unlock(mutex2);
  if(err!=0)
    error(err,"pthread_mutex_unlock");

}


void  update3(int * val1, int * val2, int * val3, pthread_mutex_t * mutex1, pthread_mutex_t * mutex2, pthrad_mutex_t * mutex3) {

  err=pthread_mutex_lock(mutex1);
  if(err!=0)
    error(err,"pthread_mutex_lock");
  err=pthread_mutex_lock(mutex2);
  if(err!=0)
    error(err,"pthread_mutex_lock");

  *val1=(*val2)+1;
  *val2=(*val1)+1;

  err=pthread_mutex_unlock(mutex1);
  if(err!=0)
    error(err,"pthread_mutex_unlock");

  err=pthread_mutex_unlock(mutex2);
  if(err!=0)
    error(err,"pthread_mutex_unlock");

}


void *func(void * param) {
  int err;
  for(int j=0;j<1000000;j++) {
    err=pthread_mutex_lock(&mutex_global);
    if(err!=0)
      error(err,"pthread_mutex_lock");
    global=increment(global);
    err=pthread_mutex_unlock(&mutex_global);
    if(err!=0)
      error(err,"pthread_mutex_unlock");
  }
  return(NULL);
}

int main (int argc, char *argv[])  {
  pthread_t thread[NTHREADS];
  int err;

  err=pthread_mutex_init( &mutex_global, NULL);
  if(err!=0)
      error(err,"pthread_mutex_init");

  for(int i=0;i<NTHREADS;i++) {
    err=pthread_create(&(thread[i]),NULL,&func,NULL);
    if(err!=0)
      error(err,"pthread_create");
  }
  for(int i=0; i<1000000000;i++) { /*...*/ }

  for(int i=NTHREADS-1;i>=0;i--) {
    err=pthread_join(thread[i],NULL);
    if(err!=0)
      error(err,"pthread_join");
  }

  err=pthread_mutex_destroy(&mutex_global);
  if(err!=0)
    error(err,"pthread_mutex_destroy");

  printf("global: %ld\n",global);

  return(EXIT_SUCCESS);
}
