
.. raw:: html

  <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
  <script type="text/javascript" src="js/jquery-shuffle.js"></script>
  <script type="text/javascript" src="js/rst-form.js"></script>
  <script type="text/javascript">$nmbr_prop = 4</script>

=================
Questionnaire RST
=================

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
culpa qui officia deserunt mollit anim id est laborum.

Question 1. 'Dérivées de polynomes'
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Lorsque l'on dérive le polynome :math:`x^4+3 \times x^2 +5 \times x+12`, on
obtient notamment le terme :

.. class:: positive

- :math:`4 \times x^3`
- :math:`5`
- :math:`6 \times x`

.. class:: negative

- :math:`4 \times x^2`

  .. class:: comment

  La dérivée de :math:`a \times x^n` est :math:`a \times n \times x^{n-1}`
- :math:`5 \times x`

  .. class:: comment

  La dérivée de :math:`a \times x^n` est :math:`a \times n \times x^{n-1}`
- :math:`12`

  .. class:: comment

  La dérivée d'un entier est :math:`0`

Question 2. 'Dérivées de polynomes'
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Lorsque l'on dérive le polynome :math:`x^4+3 \times x^2 +5 \times x+12`, on
obtient notamment le terme :

.. class:: positive

- :math:`4 \times x^3`
- :math:`5`
- :math:`6 \times x`

.. class:: negative

- :math:`4 \times x^2`

  .. class:: comment

  La dérivée de :math:`a \times x^n` est :math:`a \times n \times x^{n-1}`
- :math:`5 \times x`

  .. class:: comment

  La dérivée de :math:`a \times x^n` est :math:`a \times n \times x^{n-1}`
- :math:`12`

  .. class:: comment

  La dérivée d'un entier est :math:`0`


Question 3. 'Dérivées de polynomes'
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Lorsque l'on dérive le polynome :math:`x^4+3 \times x^2 +5 \times x+12`, on
obtient notamment le terme :

.. class:: positive

- :math:`4 \times x^3`
- :math:`5`
- :math:`6 \times x`

.. class:: negative

- :math:`4 \times x^2`

  .. class:: comment

  La dérivée de :math:`a \times x^n` est :math:`a \times n \times x^{n-1}`
- :math:`5 \times x`

  .. class:: comment

  La dérivée de :math:`a \times x^n` est :math:`a \times n \times x^{n-1}`
- :math:`12`

  .. class:: comment

  La dérivée d'un entier est :math:`0`



