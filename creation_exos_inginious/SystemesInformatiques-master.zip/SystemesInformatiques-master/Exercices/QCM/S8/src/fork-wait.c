List directory (brief): ~/Documents/Cours/SINF1252/SystemesInformatiques/Exercices/QCM/S8/src/
