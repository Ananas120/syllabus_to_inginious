.. -*- coding: utf-8 -*-
.. Copyright |copy| 2012-2014 by `Olivier Bonaventure <http://inl.info.ucl.ac.be/obo>`_, Christoph Paasch et Grégory Detal
.. Ce fichier est distribué sous une licence `creative commons <http://creativecommons.org/licenses/by-sa/3.0/>`_  

Blog
====

Un blog est associé au cours. Il est hébergé sur `github <https://www.github.com`_ et est accessible depuis l'URL 
https://obonaventure.github.io/SystInfoBlog

Il sera alimenté par les étudiant-e-s qui suivent le cours avec des informations qu'ils-elles considèrent comme
utiles. 




