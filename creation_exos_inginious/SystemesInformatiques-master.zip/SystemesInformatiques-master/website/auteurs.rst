.. -*- coding: utf-8 -*-
.. Copyright |copy| 2012-2014 by `Olivier Bonaventure <http://inl.info.ucl.ac.be/obo>`_, Christoph Paasch et Grégory Detal
.. Ce fichier est distribué sous une licence `creative commons <http://creativecommons.org/licenses/by-sa/3.0/>`_


Systèmes informatiques 
======================


 
.. only:: html

Ces notes et les exercices associés ont été écrits par :

 - `Olivier Bonaventure <http://perso.uclouvain.be/olivier.bonaventure>`_
 - `Grégory Detal`
 - `Christoph Paasch`

Avec l'aide précieuse pour les exercices de :

 - Quentin Deconinck
 - Adrien Scheuer

Et la relecture attentive de :

 - David Sarkozi
 - Simon Hardy
 - Benoît Legat
 
La section `Outils` contient du texte écrit par :
 - `Olivier Bonaventure <http://perso.uclouvain.be/olivier.bonaventure>`_
 - `Benoît Legat`
 - `Nicolas Houtain`
 - `Maxime Demol`
 - `Kilian Verhetsel`
 - `Antoine Caillau`

L'ensemble est distribué sous licence Creative Commons:

	   http://creativecommons.org/licenses/by-sa/3.0/


Les contributions des différents auteurs sont résumées dans les `statistiques <_static/gitinspector.html>`_ produites par `gitinspector <https://code.google.com/p/gitinspector/>`_ 
