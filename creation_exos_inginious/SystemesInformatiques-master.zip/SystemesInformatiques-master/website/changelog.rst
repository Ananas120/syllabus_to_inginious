=========
Changelog
=========


- Sept. 12th, 2014 : First draft of `multiple choice questions on the principles of the datalink layer <2nded:mcq-reliable>`_

- September 2014 : New web site for second edition of the ebook 


