#include <stdlib.h>

int main(int argc, char * argv[])
{
	char *ptrChars = (char *)malloc(6 * sizeof(char));
	ptrChars[0]= 'H';

	return 0;
}
